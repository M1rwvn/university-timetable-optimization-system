#!/usr/bin/env python3
import pandas as pd
import random
import json
import os
import copy
from collections import defaultdict
import time
from tabulate import tabulate

PROCESSED_DATA_DIR = "processed_data"
INITIAL_POP_PATH = "initial_population.json"
OUTPUT_DIR = "output"

# Create output directory if it doesn't exist
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- PFOA Configuration ---
NUM_GENERATIONS = 50  # Number of generations to run the PFOA
POPULATION_SIZE = 100 # Should match the size of the initial population
CROSSOVER_RATE = 0.8
MUTATION_RATE = 0.2 # Per-solution mutation rate
GENE_MUTATION_RATE = 0.1 # Per-gene (assignment) mutation rate if solution is selected for mutation

# PFOA specific parameters (placeholders, to be refined based on PFOA literature)
PREDATION_RATE = 0.1 # Probability of a solution undergoing predation (strong exploration)
SCHOOLING_FACTOR = 0.5 # Influence factor for schooling/following behavior

# --- Load Data (Copied from pfoa_fitness_repair.py for self-containment) --- #
def load_data():
    print("Loading data for PFOA core...")
    data = {}
    try:
        data["lectures"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "lectures_to_schedule.csv"))
        data["timeslots"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "valid_timeslots.csv"))
        data["classrooms"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "processed_classrooms.csv"))
        data["students"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "processed_students.csv"))
        data["courses"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "processed_courses.csv"))
        data["instructors"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "processed_instructors.csv"))
        data["enrollments"] = pd.read_csv(os.path.join(PROCESSED_DATA_DIR, "student_enrollments.csv"))
        print("All data loaded successfully for PFOA core.")
        
        # Create info dictionaries
        data["lecture_info"] = data["lectures"].set_index("lecture_id").to_dict("index")
        data["course_info"] = data["courses"].set_index("course_id").to_dict("index")
        data["classroom_info"] = data["classrooms"].set_index("classroom_id").to_dict("index")
        data["timeslot_info"] = data["timeslots"].set_index("timeslot_id").to_dict("index")
        data["instructor_info"] = data["instructors"].set_index("instructor_id").to_dict("index")
        
        # Create student-related dictionaries
        students_per_course = data["enrollments"].groupby("course_id")["student_id"].count().to_dict()
        data["students_per_course"] = students_per_course

        courses_per_student = data["enrollments"].groupby("student_id")["course_id"].apply(list).to_dict()
        data["courses_per_student"] = courses_per_student
        
        # Create available resources lists
        data["available_timeslots"] = list(data["timeslot_info"].keys())
        data["available_classrooms"] = list(data["classroom_info"].keys())

    except Exception as e:
        print(f"Error loading data in PFOA core: {e}")
        return None
    return data

# --- Fitness Function (Copied from pfoa_fitness_repair.py) --- #
def calculate_fitness(solution, all_data):
    fitness = 0
    violations = {
        "instructor_conflict": 0, "room_conflict": 0,
        "capacity_violation": 0, "student_conflict": 0
    }
    instructor_schedule = defaultdict(list)
    room_schedule = defaultdict(list)

    for assignment in solution:
        lecture_id = assignment["lecture_id"]
        timeslot_id = assignment["timeslot_id"]
        classroom_id = assignment["classroom_id"]
        lecture_details = all_data["lecture_info"].get(lecture_id)
        if not lecture_details: continue
        course_id = lecture_details["course_id"]
        instructor_id = lecture_details["instructor_id"]
        if timeslot_id in instructor_schedule[instructor_id]: violations["instructor_conflict"] += 1
        else: instructor_schedule[instructor_id].append(timeslot_id)
        if timeslot_id in room_schedule[classroom_id]: violations["room_conflict"] += 1
        else: room_schedule[classroom_id].append(timeslot_id)
        num_students = all_data["students_per_course"].get(course_id, 0)
        room_capacity = all_data["classroom_info"].get(classroom_id, {}).get("capacity", 0)
        if num_students > room_capacity: violations["capacity_violation"] += 1

    student_conflict_count = 0
    for student_id, enrolled_ids in all_data["courses_per_student"].items():
        student_ts = []
        for assign in solution:
            lec_id = assign["lecture_id"]
            assigned_cid = all_data["lecture_info"].get(lec_id, {}).get("course_id")
            if assigned_cid in enrolled_ids: student_ts.append(assign["timeslot_id"])
        if len(student_ts) != len(set(student_ts)): student_conflict_count += (len(student_ts) - len(set(student_ts)))
    violations["student_conflict"] = student_conflict_count

    total_penalty = (violations["instructor_conflict"] * 100 + violations["room_conflict"] * 100 +
                     violations["capacity_violation"] * 50 + violations["student_conflict"] * 200)
    return -total_penalty, violations

# --- Repair Function (Copied and simplified from pfoa_fitness_repair.py) --- #
def repair_solution(solution, all_data):
    repaired_solution = copy.deepcopy(solution)
    # Basic repair: if instructor or room conflict, try a new random timeslot/room for the conflicting assignment.
    # This is a very simplified repair for demonstration. A more robust one would be needed.
    # The previous repair function was complex and might be too slow for many iterations.
    # This version will be a placeholder and can be expanded if PFOA struggles.
    _, violations = calculate_fitness(repaired_solution, all_data) # Check initial violations
    if sum(violations.values()) == 0:
        return repaired_solution, False # No repair needed
    
    # Simple example: try to fix one instructor conflict by random reassignment
    # This is not a comprehensive repair. It's more of a light touch.
    changed = False
    for i in range(len(repaired_solution)):
        # Check instructor conflict for assignment i
        # If conflict, try to change timeslot_id for repaired_solution[i]
        # This requires re-calculating instructor_schedule for the current state of repaired_solution
        # For simplicity, this repair function will be very basic for now.
        pass # Placeholder for a more effective repair strategy if needed.

    return repaired_solution, changed # Return original if no simple repair implemented

# --- PFOA Operators --- # 

def selection(population_with_fitness):
    """Selects two parents using tournament selection."""
    tournament_size = 5
    parents = []
    for _ in range(2):
        tournament = random.sample(population_with_fitness, tournament_size)
        tournament.sort(key=lambda x: x[1], reverse=True) # Sort by fitness (higher is better)
        parents.append(tournament[0][0]) # Select the best from the tournament
    return parents[0], parents[1]

def crossover(parent1, parent2):
    """Performs single-point crossover."""
    if random.random() > CROSSOVER_RATE or len(parent1) <= 1:
        return copy.deepcopy(parent1), copy.deepcopy(parent2)
    
    point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2

def mutate(solution, all_data):
    """Mutates a solution by changing a few assignments randomly."""
    if random.random() > MUTATION_RATE:
        return solution
    
    mutated_solution = copy.deepcopy(solution)
    num_mutations = 0
    for i in range(len(mutated_solution)):
        if random.random() < GENE_MUTATION_RATE:
            num_mutations += 1
            # Change timeslot or classroom for this assignment
            if random.random() < 0.5: # Mutate timeslot
                mutated_solution[i]["timeslot_id"] = random.choice(all_data["available_timeslots"])
            else: # Mutate classroom
                mutated_solution[i]["classroom_id"] = random.choice(all_data["available_classrooms"])
    # print(f"Performed {num_mutations} gene mutations in one solution")
    return mutated_solution

# PFOA-specific behaviors (Predation and Schooling/Following)
def predation(solution, all_data):
    """ PFOA Predation behavior: Pufferfish inflates, explores new area (strong mutation)."""
    # This is a more drastic mutation than the standard one.
    # For example, re-assign a larger portion of the schedule randomly.
    predated_solution = copy.deepcopy(solution)
    num_genes_to_predate = int(len(predated_solution) * 0.2) # Predate 20% of genes
    indices_to_predate = random.sample(range(len(predated_solution)), num_genes_to_predate)
    for i in indices_to_predate:
        predated_solution[i]["timeslot_id"] = random.choice(all_data["available_timeslots"])
        predated_solution[i]["classroom_id"] = random.choice(all_data["available_classrooms"])
    return predated_solution

def schooling_and_following(solution, best_solution_in_pop, all_data):
    """ PFOA Schooling/Following behavior: Move towards the best solution."""
    # For each assignment, if not matching the best, move towards it with some probability
    schooled_solution = copy.deepcopy(solution)
    for i in range(len(schooled_solution)):
        if random.random() < SCHOOLING_FACTOR: # Probability to follow
            # If this gene differs from the best solution's gene, adopt the best's gene
            if schooled_solution[i]["timeslot_id"] != best_solution_in_pop[i]["timeslot_id"]:
                schooled_solution[i]["timeslot_id"] = best_solution_in_pop[i]["timeslot_id"]
            if schooled_solution[i]["classroom_id"] != best_solution_in_pop[i]["classroom_id"]:
                schooled_solution[i]["classroom_id"] = best_solution_in_pop[i]["classroom_id"]
    return schooled_solution

# --- Main PFOA Loop --- #
def run_pfoa(all_data):
    print("\nStarting Puffer Fish Optimization Algorithm...")
    # Load initial population
    try:
        with open(INITIAL_POP_PATH, "r") as f:
            initial_solution = json.load(f)
            # Create population by duplicating the initial solution
            population = [copy.deepcopy(initial_solution) for _ in range(POPULATION_SIZE)]
        print(f"Initial population loaded successfully with size {len(population)}")
    except Exception as e:
        print(f"Error loading initial population from {INITIAL_POP_PATH}: {e}")
        return None, []

    best_solution_overall = None
    best_fitness_overall = -float("inf")
    fitness_history = [] # To track best fitness per generation

    start_time = time.time()
    for generation in range(NUM_GENERATIONS):
        gen_start_time = time.time()
        print(f"\nGeneration {generation + 1}/{NUM_GENERATIONS}")

        # Calculate fitness for each solution
        population_with_fitness = []
        for sol in population:
            fitness, violations = calculate_fitness(sol, all_data)
            population_with_fitness.append((sol, fitness, violations))
        
        # Sort population by fitness (descending, higher is better)
        population_with_fitness.sort(key=lambda x: x[1], reverse=True)
        
        current_best_solution_in_gen = population_with_fitness[0][0]
        current_best_fitness_in_gen = population_with_fitness[0][1]
        current_best_violations_in_gen = population_with_fitness[0][2]

        fitness_history.append({"generation": generation + 1, "best_fitness": current_best_fitness_in_gen, "violations": current_best_violations_in_gen})
        print(f"Best fitness in Gen {generation + 1}: {current_best_fitness_in_gen}, Violations: {current_best_violations_in_gen}")

        if current_best_fitness_in_gen > best_fitness_overall:
            best_fitness_overall = current_best_fitness_in_gen
            best_solution_overall = copy.deepcopy(current_best_solution_in_gen)
            print(f"New overall best solution found in Gen {generation + 1}!")

        new_population = []
        # Elitism: Carry over the top 10% of solutions
        elitism_count = int(0.1 * len(population))
        for i in range(elitism_count):
            new_population.append(population_with_fitness[i][0])

        # Generate the rest of the new population
        while len(new_population) < len(population):
            parent1, parent2 = selection(population_with_fitness)
            child1, child2 = crossover(parent1, parent2)
            
            child1 = mutate(child1, all_data)
            child2 = mutate(child2, all_data)

            # Apply PFOA specific operators
            if random.random() < PREDATION_RATE:
                child1 = predation(child1, all_data)
            else:
                child1 = schooling_and_following(child1, current_best_solution_in_gen, all_data)
            
            if random.random() < PREDATION_RATE:
                child2 = predation(child2, all_data)
            else:
                child2 = schooling_and_following(child2, current_best_solution_in_gen, all_data)
            
            # Optional: Apply repair function (can be computationally expensive)
            # child1, _ = repair_solution(child1, all_data)
            # child2, _ = repair_solution(child2, all_data)

            new_population.append(child1)
            if len(new_population) < len(population):
                new_population.append(child2)
        
        population = new_population
        gen_end_time = time.time()
        print(f"Generation {generation + 1} took {gen_end_time - gen_start_time:.2f} seconds.")

    total_time = time.time() - start_time
    print(f"\nPFOA finished after {NUM_GENERATIONS} generations.")
    print(f"Total optimization time: {total_time:.2f} seconds.")
    print(f"Best fitness found: {best_fitness_overall}")
    if best_solution_overall:
        _, best_violations = calculate_fitness(best_solution_overall, all_data)
        print(f"Violations in best solution: {best_violations}")

    return best_solution_overall, fitness_history

def create_timetable_table(solution, all_data):
    """Convert the solution into a readable table format."""
    table_data = []
    
    # Sort assignments by day and start time for better readability
    sorted_solution = sorted(solution, key=lambda x: (
        all_data["timeslot_info"][x["timeslot_id"]]["day"],
        all_data["timeslot_info"][x["timeslot_id"]]["start_time"]
    ))
    
    for assignment in sorted_solution:
        try:
            lecture_id = assignment["lecture_id"]
            timeslot_id = assignment["timeslot_id"]
            classroom_id = assignment["classroom_id"]

            lecture_info = all_data["lecture_info"][lecture_id]
            course_id = lecture_info["course_id"]
            instructor_id = lecture_info["instructor_id"]

            course_name = all_data["course_info"][course_id]["course_name"]
            instructor_name = all_data["instructor_info"][instructor_id]["name"]
            timeslot_info = all_data["timeslot_info"][timeslot_id]
            classroom_info = all_data["classroom_info"][classroom_id]

            row = [
                timeslot_info["day"],
                timeslot_info["start_time"],
                timeslot_info["end_time"],
                course_name,
                instructor_name,
                f"Room {classroom_id}",
                f"Capacity: {classroom_info['capacity']}"
            ]
            table_data.append(row)
        except KeyError as e:
            print(f"Warning: Skipping assignment due to missing data: {e}")
            continue

    headers = ["Day", "Start Time", "End Time", "Course", "Instructor", "Room", "Room Details"]
    table = tabulate(table_data, headers=headers, tablefmt="grid")
    return table

if __name__ == "__main__":
    all_data = load_data()
    if not all_data:
        print("Failed to load data. Exiting PFOA.")
        exit(1)
    
    if not all_data.get("available_timeslots") or not all_data.get("available_classrooms"):
        print("Available timeslots or classrooms are empty. PFOA cannot proceed.")
        exit(1)

    best_solution, history = run_pfoa(all_data)

    if best_solution:
        # Save best solution
        best_solution_path = os.path.join(OUTPUT_DIR, "pfoa_best_solution.json")
        with open(best_solution_path, "w") as f:
            json.dump(best_solution, f, indent=4)
        print(f"Best solution saved to {best_solution_path}")
        
        # Create and display timetable table
        timetable_table = create_timetable_table(best_solution, all_data)
        print("\nGenerated Timetable:")
        print(timetable_table)
        
        # Save timetable to file
        timetable_path = os.path.join(OUTPUT_DIR, "timetable.txt")
        with open(timetable_path, "w") as f:
            f.write(timetable_table)
        print(f"\nTimetable saved to {timetable_path}")
    
    # Save fitness history
    history_path = os.path.join(OUTPUT_DIR, "pfoa_fitness_history.json")
    with open(history_path, "w") as f:
        json.dump(history, f, indent=4)
    print(f"Fitness history saved to {history_path}")

    print("\nScript pfoa_core.py finished.")

